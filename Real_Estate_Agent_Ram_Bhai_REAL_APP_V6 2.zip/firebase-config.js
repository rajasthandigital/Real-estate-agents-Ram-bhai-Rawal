// FIREBASE CONFIGURATION
// Create a Firebase project, enable Authentication (Phone + Google) and Firestore,
// then paste your web app configuration below.
//
// IMPORTANT: Do not put service-account/private keys in this file.

export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_YOUR_SENDER_ID",
  appId: "PASTE_YOUR_APP_ID"
};
