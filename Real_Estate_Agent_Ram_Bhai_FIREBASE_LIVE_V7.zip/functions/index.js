const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
initializeApp();
const db=getFirestore();

exports.checkAvailability=onCall(async (request)=>{
  if(!request.auth) throw new HttpsError("unauthenticated","Login required.");
  const {location="",type="House",minBudget=0,maxBudget=Infinity}=request.data||{};
  const snap=await db.collection("properties").where("status","==","Available").where("type","==",type).get();
  const loc=String(location).trim().toLowerCase();
  let count=0;
  for(const doc of snap.docs){
    const p=doc.data();
    const ploc=String(p.location||"").toLowerCase();
    if(loc && !ploc.includes(loc)) continue;
    const pmin=Number(p.min||0), pmax=Number(p.max||0);
    if(pmax>=Number(minBudget) && pmin<=Number(maxBudget)) count++;
  }
  // Only return the count. Never return price, photo, exact location or internal notes.
  return {available: count>0, count};
});
