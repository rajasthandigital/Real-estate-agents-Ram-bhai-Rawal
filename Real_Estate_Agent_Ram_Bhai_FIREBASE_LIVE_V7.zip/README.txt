RAM BHAI RAWAL REAL ESTATE — V4 ADMIN PANEL

Files:
- index.html = client availability app
- admin.html = private agent admin panel
- manifest.webmanifest / sw.js / icon.svg = PWA files

Prototype admin login:
Username: admin
Password: 1234

Admin features:
- Add / edit / delete properties
- Store exact location, price range, area, photo URL and internal notes
- Change property status: Available / Booked / Sold
- Dashboard counts
- View meeting requests

IMPORTANT:
This is a browser prototype. Data is stored in localStorage, so it is NOT a real secure multi-device admin system yet.
For the final live app, use Firebase/Supabase (or another backend) with real authentication and a database so the agent can update availability from one device and clients see the same live availability.

CLIENT LOGIN V5
- Client app now requires login before using the app.
- Login options: 10-digit mobile number OR Gmail.
- Prototype stores login locally in the browser.
- Production recommendation: Mobile OTP + Google Sign-In with Firebase Authentication.


V6: Client app redesigned in premium light luxury theme and prepared for Firebase production integration.


V7 LIVE FIREBASE: Authentication + Firestore + server-side availability architecture prepared. See FIREBASE_SETUP_HINDI.txt.
